module.exports=[24361,(r,e,t)=>{e.exports=r.x("util",()=>require("util"))},88947,(r,e,t)=>{e.exports=r.x("stream",()=>require("stream"))},874,(r,e,t)=>{e.exports=r.x("buffer",()=>require("buffer"))},54799,(r,e,t)=>{e.exports=r.x("crypto",()=>require("crypto"))},22734,(r,e,t)=>{e.exports=r.x("fs",()=>require("fs"))}];

//# sourceMappingURL=%5Bexternals%5D__dca7b304._.js.map