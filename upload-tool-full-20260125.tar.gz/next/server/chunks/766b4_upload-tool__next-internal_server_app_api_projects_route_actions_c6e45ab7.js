module.exports=[87401,(e,o,d)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app_api_projects_route_actions_c6e45ab7.js.map