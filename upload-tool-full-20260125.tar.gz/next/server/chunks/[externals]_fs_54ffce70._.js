module.exports=[22734,(e,r,s)=>{r.exports=e.x("fs",()=>require("fs"))}];

//# sourceMappingURL=%5Bexternals%5D_fs_54ffce70._.js.map