module.exports=[29867,(e,o,d)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app_api_module-configs_route_actions_d7a2dc5f.js.map