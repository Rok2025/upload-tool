module.exports=[24868,(s,e,r)=>{e.exports=s.x("fs/promises",()=>require("fs/promises"))}];

//# sourceMappingURL=%5Bexternals%5D_fs_promises_0bfe4114._.js.map