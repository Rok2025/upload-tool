module.exports=[60308,(e,o,d)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app_api_permissions_route_actions_f1bae5e3.js.map