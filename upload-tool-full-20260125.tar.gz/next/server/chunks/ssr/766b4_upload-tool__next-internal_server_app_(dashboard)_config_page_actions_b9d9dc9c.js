module.exports=[39823,(a,b,c)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app_%28dashboard%29_config_page_actions_b9d9dc9c.js.map