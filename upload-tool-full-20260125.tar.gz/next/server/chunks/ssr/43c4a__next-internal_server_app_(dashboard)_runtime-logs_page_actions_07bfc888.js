module.exports=[31521,(a,b,c)=>{}];

//# sourceMappingURL=43c4a__next-internal_server_app_%28dashboard%29_runtime-logs_page_actions_07bfc888.js.map