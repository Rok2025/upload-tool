module.exports=[12341,(a,b,c)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app__not-found_page_actions_70e8c4bc.js.map