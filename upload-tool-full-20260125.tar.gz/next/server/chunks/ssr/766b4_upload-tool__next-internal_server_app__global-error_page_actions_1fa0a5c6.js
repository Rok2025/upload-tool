module.exports=[93576,(a,b,c)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app__global-error_page_actions_1fa0a5c6.js.map