module.exports=[70449,(a,b,c)=>{}];

//# sourceMappingURL=766b4_upload-tool__next-internal_server_app_%28dashboard%29_history_page_actions_4403a197.js.map