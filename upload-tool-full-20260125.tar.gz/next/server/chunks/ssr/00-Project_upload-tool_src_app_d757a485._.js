module.exports=[87218,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},94730,a=>{"use strict";let b={src:a.i(87218).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=00-Project_upload-tool_src_app_d757a485._.js.map