var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/04dbd_next_dist_esm_build_templates_app-route_b7401085.js")
R.c("server/chunks/04dbd_next_ac35bf59._.js")
R.c("server/chunks/[root-of-the-server]__ce15e934._.js")
R.c("server/chunks/766b4_upload-tool__next-internal_server_app_favicon_ico_route_actions_3349bb9c.js")
R.m(19645)
module.exports=R.m(19645).exports
