var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__71ffce3f._.js")
R.c("server/chunks/[root-of-the-server]__ce15e934._.js")
R.c("server/chunks/04dbd_next_ac35bf59._.js")
R.c("server/chunks/766b4_upload-tool__next-internal_server_app_api_upload_route_actions_88e3a88a.js")
R.m(75753)
module.exports=R.m(75753).exports
