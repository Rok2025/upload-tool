var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/route.js")
R.c("server/chunks/[root-of-the-server]__599f0c06._.js")
R.c("server/chunks/04dbd_next_ac35bf59._.js")
R.c("server/chunks/[root-of-the-server]__0c9d2c21._.js")
R.c("server/chunks/[root-of-the-server]__ce15e934._.js")
R.c("server/chunks/766b4_upload-tool__next-internal_server_app_api_stats_route_actions_d57d0409.js")
R.m(86107)
module.exports=R.m(86107).exports
