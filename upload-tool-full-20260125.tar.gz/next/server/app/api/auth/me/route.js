var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__a18187f4._.js")
R.c("server/chunks/04dbd_next_ac35bf59._.js")
R.c("server/chunks/00-Project_upload-tool_b4f73dc0._.js")
R.c("server/chunks/[root-of-the-server]__ce15e934._.js")
R.c("server/chunks/766b4_upload-tool__next-internal_server_app_api_auth_me_route_actions_4e4dade4.js")
R.m(36611)
module.exports=R.m(36611).exports
