var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logs/route.js")
R.c("server/chunks/[root-of-the-server]__2fc29ddd._.js")
R.c("server/chunks/00-Project_upload-tool_795a7691._.js")
R.c("server/chunks/[root-of-the-server]__ce15e934._.js")
R.c("server/chunks/[root-of-the-server]__0c9d2c21._.js")
R.c("server/chunks/00-Project_upload-tool__next-internal_server_app_api_logs_route_actions_0ec8d03f.js")
R.m(64984)
module.exports=R.m(64984).exports
